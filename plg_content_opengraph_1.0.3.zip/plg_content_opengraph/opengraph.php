<?php
// no direct access
defined('_JEXEC') or die;

class plgContentOpengraph extends JPlugin
{
	protected $autoloadLanguage = true;
	protected $tags = array();

	/**
	 * Plugin method onContentAfterTitle adds content after TITLE tag
	 */
	function onContentAfterTitle($content,&$article,&$params,$limitstart=0) {
		/*
		 * Plugin code goes here.
		 * You can access database and application objects and parameters via $this->db,
		 * $this->app and $this->params respectively
		 */
		$doc = JFactory::getDocument();
		$images = json_decode($article->images);
		$this->tags['og-title'] = array('property'=>"og:title",'content'=>$doc->getTitle());
		$this->tags['og-url'] = array('property'=>"og:url",'content'=>$doc->getBase());
		$this->tags['og-type'] = array('property'=>"og:type",'content'=>"Article");
		$this->tags['og-description'] = array('property'=>"og:description",'content'=>strip_tags($article->introtext));
		$this->tags['og-locale'] = array('property'=>"og:locale",'content'=>$doc->getLanguage());
		$this->tags['og-image'] = array('property'=>"og:image",'content'=>$images->image_fulltext);
		$this->tags['og-image-alt'] = array('property'=>"og:image:alt",'content'=>$images->image_fulltext_alt);
		if($this->params->get('fbappid',"")!="")
			$this->tags['fb-app-id'] = array('property'=>"fb:app_id",'content'=>$this->params->get('fbappid',""));
		if($this->params->get('fbpageid',"")!="")
			$this->tags['fb-page-id'] = array('property'=>"fb:page_id",'content'=>$this->params->get('fbpageid',""));
		foreach($this->tags as $tag) {
			$doc->setMetaData($tag['property'],$tag['content'],'property');
		}
		return true;
	}
}
?>